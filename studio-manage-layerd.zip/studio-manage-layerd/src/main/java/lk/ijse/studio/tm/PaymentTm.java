package lk.ijse.studio.tm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PaymentTm {
    private String payment_id;
    private String client_id;
    private String booking_id;
    private String amount;
    private String date;

}
