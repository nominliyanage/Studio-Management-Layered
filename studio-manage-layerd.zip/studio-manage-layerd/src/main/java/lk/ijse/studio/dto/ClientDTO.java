package lk.ijse.studio.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ClientDTO { // this model class represent real world client entity
    private String client_id;
    private String name;
    private String user_id;
    private String tel;

}
