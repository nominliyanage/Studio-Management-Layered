package lk.ijse.studio.tm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class SalaryTm {
    private String salary_id;
    private String employee_id;
    private String amount;
    private String date;

}
