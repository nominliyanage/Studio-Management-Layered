package lk.ijse.studio.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Equipment { // this model class represent real world client entity
    private String equipment_id;
    private String equipment_name;
    private String purchase_date;
    private String maintain_history;

}
