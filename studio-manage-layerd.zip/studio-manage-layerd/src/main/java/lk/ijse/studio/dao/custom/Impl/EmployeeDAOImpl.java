package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;
import lk.ijse.studio.entity.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAOImpl {
    public static boolean save(Employee entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your employee
        return SQLUtil.execute("INSERT INTO employee (employee_id = ?, name = ?, tel = ?, role = ?, user_id = ?) VALUES (?,?,?,?,?) ", entity.getEmployee_id(), entity.getEmployee_name(), entity.getTel(), entity.getRole(), entity.getUser_id());

    }

    public static boolean update(Employee entity) throws SQLException, ClassNotFoundException{
        return SQLUtil.execute("UPDATE employee SET name = ?, tel = ?, role = ?, user_id = ? WHERE employee_id = ?", entity.getEmployee_name(), entity.getTel(), entity.getRole(), entity.getUser_id(), entity.getEmployee_id());

    }

    public static Employee searchById(String employee_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM employee WHERE employee_id = ?");
        rst.next();
        return new Employee(employee_id + "", rst.getString("employee_name"), rst.getString("tel"), rst.getString("role"), rst.getString("user_id"));
    }

    public static boolean delete(String employee_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM employee WHERE employee_id=?", employee_id);
    }

    public static ArrayList<Employee> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Employee> allEmployee = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM employee");
        while (rst.next()) {
            Employee employee = new Employee(rst.getString("employee_id"), rst.getString("name"),rst.getString("tel"),rst.getString("role"), rst.getString("user_id"));
            allEmployee.add(employee);
        }
        return allEmployee;
    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT employee_id FROM employee");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("employee_id"));
        }
        return idList;
    }
}
