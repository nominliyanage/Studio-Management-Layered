package lk.ijse.studio.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PackageDTO {
    private String package_id;
    private String package_name;
    private String price;
    private String includes;

}
