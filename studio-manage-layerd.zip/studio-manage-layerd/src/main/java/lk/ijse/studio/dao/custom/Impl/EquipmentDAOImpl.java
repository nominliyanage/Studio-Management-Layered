package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;
import lk.ijse.studio.entity.Employee;
import lk.ijse.studio.entity.Equipment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EquipmentDAOImpl {
    public static boolean save(Equipment entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your equipment
        String sql = "INSERT INTO equipment VALUES(?, ?, ?, ?)";
        return SQLUtil.execute("INSERT INTO equipment (equipment_id = ?, equipment_name = ?, purchase_date = ?, maintain_history = ?) VALUES (?,?,?,?) ", entity.getEquipment_id(), entity.getEquipment_name(), entity.getPurchase_date(), entity.getMaintain_history());

    }

    public static boolean update(Equipment entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("UPDATE equipment SET equipment_name = ?, purchase_date = ?, maintain_history = ? WHERE equipment_id = ?", entity.getEquipment_name(), entity.getPurchase_date(), entity.getMaintain_history(), entity.getEquipment_id());


    }

    public static Equipment searchById(String equipment_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM equipment WHERE equipment_id = ?");
        rst.next();
        return new Equipment(equipment_id + "", rst.getString("name"),rst.getString("purchase_date"),rst.getString("maintain_history"));
    }

    public static boolean delete(String equipment_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM equipment WHERE equipment_id = ?", equipment_id);
    }

    public static ArrayList<Equipment> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Equipment> allEquipment = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM equipment");
        while (rst.next()) {
            Equipment equipment = new Equipment(rst.getString("equipment_id"), rst.getString("name"),rst.getString("purchase_date"),rst.getString("maintain_history"));
            allEquipment.add(equipment);
        }
        return allEquipment;

    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT equipment_id FROM equipment");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("equipment_id"));
        }
        return idList;
    }
}
