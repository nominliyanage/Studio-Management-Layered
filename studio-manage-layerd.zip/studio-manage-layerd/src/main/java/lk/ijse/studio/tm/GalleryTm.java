package lk.ijse.studio.tm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class GalleryTm {
    private String gallery_id;
    private String name;
    private String date;
    private String description;
    private String client_id;


}
