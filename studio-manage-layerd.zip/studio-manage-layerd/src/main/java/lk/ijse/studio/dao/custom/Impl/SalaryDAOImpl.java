package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;
import lk.ijse.studio.entity.Salary;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SalaryDAOImpl {
    public static boolean save(Salary entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your salary
        return SQLUtil.execute("INSERT INTO salary (salary_id = ?, employee_id = ?, amount = ?, date = ?) VALUES (?,?,?,?) ", entity.getSalary_id(), entity.getEmployee_id(), entity.getAmount(), entity.getDate());

    }

    public static boolean update(Salary entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("UPDATE salary SET employee_id = ?, amount = ?, date = ? WHERE salary_id = ?", entity.getEmployee_id(), entity.getAmount(), entity.getDate(), entity.getSalary_id());

    }

    public static Salary searchById(String salary_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM salary WHERE salary_id = ?");
        rst.next();
        return new Salary(salary_id + "", rst.getString("employee_id"),rst.getString("amount"),rst.getString("date"));
    }

    public static boolean delete(String salary_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM salary WHERE salary_id = ?", salary_id);
    }

    public static ArrayList<Salary> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Salary> allSalary = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM salary");
        while (rst.next()) {
            Salary salary = new Salary(rst.getString("salary_id"), rst.getString("employee_id"),rst.getString("amount"),rst.getString("date"));
            allSalary.add(salary);
        }
        return allSalary;
    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT salary_id FROM salary");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("salary_id"));
        }
        return idList;
    }
}
