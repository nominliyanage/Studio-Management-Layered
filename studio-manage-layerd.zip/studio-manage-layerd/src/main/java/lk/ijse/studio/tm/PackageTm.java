package lk.ijse.studio.tm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PackageTm {
    private String package_id;
    private String package_name;
    private String price;
    private String includes;

}
