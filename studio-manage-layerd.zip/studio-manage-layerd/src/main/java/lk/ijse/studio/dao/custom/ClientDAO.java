package lk.ijse.studio.dao.custom;

import lk.ijse.studio.dao.CrudDAO;
import lk.ijse.studio.entity.Client;

import java.sql.SQLException;
import java.util.List;

public interface ClientDAO extends CrudDAO<Client> {
    String currentID() throws SQLException, ClassNotFoundException;
    List<String> getIds() throws SQLException, ClassNotFoundException;
}
