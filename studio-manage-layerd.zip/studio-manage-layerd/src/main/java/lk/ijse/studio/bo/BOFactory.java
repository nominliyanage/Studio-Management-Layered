package lk.ijse.studio.bo;

public class BOFactory {
}
