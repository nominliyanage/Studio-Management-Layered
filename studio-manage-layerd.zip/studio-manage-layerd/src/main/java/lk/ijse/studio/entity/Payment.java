package lk.ijse.studio.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Payment { // this model class represent real world client entity
    private String payment_id;
    private String client_id;
    private String booking_id;
    private String amount;
    private String date;

}
