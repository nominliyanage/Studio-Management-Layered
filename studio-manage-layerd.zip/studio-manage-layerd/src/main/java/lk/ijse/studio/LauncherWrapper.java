package lk.ijse.studio;

public class LauncherWrapper {
    public static void main(String[] args) {
        Launcher.main(args);

    }
}
