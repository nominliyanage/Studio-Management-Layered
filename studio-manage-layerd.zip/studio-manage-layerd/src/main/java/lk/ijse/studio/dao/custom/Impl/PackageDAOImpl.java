package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;
import lk.ijse.studio.entity.Package;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PackageDAOImpl {
    public static boolean save(Package entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your package
        return SQLUtil.execute("INSERT INTO package (package_id = ?, name = ?, price = ?, includes = ?) VALUES (?,?,?,?) ", entity.getPackage_id(), entity.getPackage_name(), entity.getPrice(), entity.getIncludes());
    }

    public static boolean update(Package entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("UPDATE package SET package_name = ?, price = ?, includes = ? WHERE package_id = ?", entity.getPackage_name(), entity.getPrice(), entity.getIncludes(), entity.getPackage_id());

    }

    public static Package searchById(String package_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM package WHERE package_id = ?");
        rst.next();
        return new Package(package_id + "", rst.getString("name"),rst.getString("price"),rst.getString("includes"));
    }

    public static boolean delete(String package_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM package WHERE package_id = ?", package_id);
    }

    public static ArrayList<Package> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Package> allPackage = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM package");
        while (rst.next()) {
            Package apackage = new Package(rst.getString("client_id"), rst.getString("name"),rst.getString("user_id"),rst.getString("tel"));
            allPackage.add(apackage);
        }
        return allPackage;
    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT package_id FROM package");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("package_id"));
        }
        return idList;
    }
}
