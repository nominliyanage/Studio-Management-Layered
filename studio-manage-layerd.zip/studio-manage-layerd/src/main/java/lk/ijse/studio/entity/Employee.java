package lk.ijse.studio.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Employee { // this model class represent real world client entity
    private String employee_id;
    private String employee_name;
    private String tel;
    private String role;
    private String user_id;

}
