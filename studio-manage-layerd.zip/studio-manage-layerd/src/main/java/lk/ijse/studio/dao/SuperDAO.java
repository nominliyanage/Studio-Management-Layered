package lk.ijse.studio.dao;

public interface SuperDAO {
}
