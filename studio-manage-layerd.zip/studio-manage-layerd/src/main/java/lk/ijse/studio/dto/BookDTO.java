package lk.ijse.studio.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class BookDTO {
    private String bookingId;
    private String userId;
    private String clientId;
    private String employeeId;
    private String packageId;
    private String date;
    private String time;
    private String location;
    private double total;
}