package lk.ijse.studio.dao.custom;

import java.sql.SQLException;
import java.util.List;

public interface PaymentDAO {
    String currentID() throws SQLException, ClassNotFoundException;
    List<String> getIds() throws SQLException, ClassNotFoundException;
}
