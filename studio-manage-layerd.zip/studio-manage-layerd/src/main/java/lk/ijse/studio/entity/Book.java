package lk.ijse.studio.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class Book {
    private String bookingId;
    private String userId;
    private String clientId;
    private String employeeId;
    private String packageId;
    private String date;
    private String time;
    private String location;
    private double total;
}