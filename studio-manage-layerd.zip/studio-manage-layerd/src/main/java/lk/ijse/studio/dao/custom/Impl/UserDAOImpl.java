package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl {
    public static boolean save(User entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("INSERT INTO user (user_id = ?, name = ?, password = ?) VALUES (?,?,?) ", entity.getUser_id(), entity.getName(), entity.getPassword());
    }

    public static ArrayList<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT user_id FROM user");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("user_id"));
        }
        return (ArrayList<String>) idList;
    }
}
