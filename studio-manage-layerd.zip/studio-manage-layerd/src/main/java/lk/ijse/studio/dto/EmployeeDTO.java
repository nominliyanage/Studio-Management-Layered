package lk.ijse.studio.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class EmployeeDTO { // this model class represent real world client entity
    private String employee_id;
    private String employee_name;
    private String tel;
    private String role;
    private String user_id;

}
