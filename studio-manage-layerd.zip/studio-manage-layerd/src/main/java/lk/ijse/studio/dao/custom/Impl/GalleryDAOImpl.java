package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;
import lk.ijse.studio.entity.Gallery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GalleryDAOImpl {
    public static boolean save(Gallery entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your gallery
        return SQLUtil.execute("INSERT INTO gallery (gallery_id = ?, name = ?, date = ?, description = ?, client_id) VALUES (?,?,?,?,?) ", entity.getGallery_id(), entity.getName(), entity.getDate(), entity.getDescription(), entity.getClient_id());
    }

    public static boolean update(Gallery entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("UPDATE gallery SET name = ?, date = ?, description = ?, client_id = ? WHERE gallery_id = ?", entity.getName(), entity.getDate(), entity.getDescription(), entity.getClient_id(), entity.getGallery_id());
    }

    public static Gallery searchById(String gallery_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM gallery WHERE gallery_id = ?");
        rst.next();
        return new Gallery(gallery_id + "", rst.getString("name"),rst.getString("date"),rst.getString("description"), rst.getString("client_id"));
    }

    public static boolean delete(String gallery_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM gallery WHERE gallery_id = ?", gallery_id);
    }

    public static ArrayList<Gallery> getAll() throws SQLException, ClassNotFoundException {

        ArrayList<Gallery> allGallery = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM gallery");
        while (rst.next()) {
            Gallery gallery = new Gallery(rst.getString("gallery_id"), rst.getString("name"),rst.getString("date"),rst.getString("description"), rst.getString("client_id"));
            allGallery.add(gallery);
        }
        return allGallery;
    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {

        ResultSet rst = SQLUtil.execute("SELECT gallery_id FROM gallery");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("gallery_id"));
        }
        return idList;
    }
}
