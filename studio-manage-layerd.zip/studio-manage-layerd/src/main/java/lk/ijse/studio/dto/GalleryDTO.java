package lk.ijse.studio.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class GalleryDTO { // this model class represent real world client entity
    private String gallery_id;
    private String name;
    private String date;
    private String description;
    private String client_id;

}
