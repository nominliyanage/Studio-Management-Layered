package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClientDAOImpl {
    public static boolean save(Client entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your client
        return SQLUtil.execute("INSERT INTO client (client_id = ?, name = ?, user_id = ?, tel = ?) VALUES (?,?,?,?) ", entity.getClient_id(), entity.getName(), entity.getUser_id(), entity.getTel());
    }

    public static boolean update(Client entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("UPDATE client SET name = ?, user_id = ?, tel = ? WHERE client_id = ?", entity.getName(), entity.getUser_id(), entity.getTel(), entity.getClient_id());
    }

    public static Client searchById(String client_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM client WHERE client_id = ?");
        rst.next();
        return new Client(client_id + "", rst.getString("name"),rst.getString("address"),rst.getString("tel"));
    }

    public static boolean delete(String client_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM client WHERE client_id=?", client_id);
    }

    public static ArrayList<Client> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Client> allClient = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM client");
        while (rst.next()) {
            Client client = new Client(rst.getString("client_id"), rst.getString("name"),rst.getString("user_id"),rst.getString("tel"));
            allClient.add(client);
        }
        return allClient;
    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT client_id FROM client");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("client_id"));
        }
        return idList;
    }
}
