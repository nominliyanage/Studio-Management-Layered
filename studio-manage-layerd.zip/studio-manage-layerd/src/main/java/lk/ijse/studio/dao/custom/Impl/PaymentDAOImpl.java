package lk.ijse.studio.dao.custom.Impl;

import lk.ijse.studio.dao.SQLUtil;
import lk.ijse.studio.entity.Client;
import lk.ijse.studio.entity.Package;
import lk.ijse.studio.entity.Payment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAOImpl {
    public static boolean save(Payment entity) throws SQLException, ClassNotFoundException {
//        In here you can now save your payment
        return SQLUtil.execute("INSERT INTO payment (payment_id = ?, client_id = ?, booking_id = ?, amount = ?, date = ?) VALUES (?,?,?,?) ", entity.getPayment_id(), entity.getClient_id(), entity.getBooking_id(), entity.getAmount(), entity.getDate());

    }

    public static boolean update(Payment entity) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("UPDATE payment SET client_id = ?, booking_id = ?, amount = ?, date = ? WHERE payment_id = ?", entity.getClient_id(), entity.getBooking_id(), entity.getAmount(), entity.getDate(), entity.getPayment_id());

    }

    public static Payment searchById(String payment_id) throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT * FROM payment WHERE payment_id = ?");
        rst.next();
        return new Payment(payment_id + "", rst.getString("client_id"),rst.getString("booking_id"),rst.getString("amount"), rst.getString("date"));
    }

    public static boolean delete(String payment_id) throws SQLException, ClassNotFoundException {
        return SQLUtil.execute("DELETE FROM payment WHERE payment_id = ?", payment_id);
    }

    public static ArrayList<Payment> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<Payment> allPayment = new ArrayList<>();
        ResultSet rst = SQLUtil.execute("SELECT * FROM payment");
        while (rst.next()) {
            Payment payment = new Payment(rst.getString("payment_id"), rst.getString("client_id"),rst.getString("booking_id"),rst.getString("amount"), rst.getString("date"));
            allPayment.add(payment);
        }
        return allPayment;
    }

    public static List<String> getIds() throws SQLException, ClassNotFoundException {
        ResultSet rst = SQLUtil.execute("SELECT payment_id FROM payment");
        List<String> idList = new ArrayList<>();
        while (rst.next()) {
            idList.add(rst.getString("payment_id"));
        }
        return idList;
    }
}
