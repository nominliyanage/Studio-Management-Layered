package lk.ijse.studio.bo;

public interface SuperBO {
}
